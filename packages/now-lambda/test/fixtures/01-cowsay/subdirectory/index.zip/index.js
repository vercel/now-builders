'use strict';

exports.handler = async function () {
  return {
    statusCode: 200,
    headers: {},
    body: 'yoda:RANDOMNESS_PLACEHOLDER'
  };
};
